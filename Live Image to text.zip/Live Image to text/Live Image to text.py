import cv2, pytesseract, datetime as dt, numpy as np
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

# config
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
SERVICE_ACCOUNT_FILE = "service_account.json"
SPREADSHEET_ID = "1T5zkpPKKE7o-7cPVjrGiqqFArCfWx3lRJihyIlwFOtI"
SHEET_NAME = "ID_Scans"

# google sheets setup
creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/spreadsheets"])
sheets = build("sheets", "v4", credentials=creds)

def append_to_sheet(text):
    row = [dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), text]
    sheets.spreadsheets().values().append(
        spreadsheetId=SPREADSHEET_ID,
        range=f"{SHEET_NAME}!A:B",
        valueInputOption="USER_ENTERED",
        body={"values":[row]}
    ).execute()

# ---- detect and crop card ----
def detect_card(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 200)
    cnts, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[:5]

    for c in cnts:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02*peri, True)
        if len(approx) == 4:  # found rectangle
            pts = approx.reshape(4, 2).astype("float32")
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]
            (tl, tr, br, bl) = rect
            width = int(max(np.linalg.norm(br-bl), np.linalg.norm(tr-tl)))
            height = int(max(np.linalg.norm(tr-br), np.linalg.norm(tl-bl)))
            dst = np.array([[0, 0], [width-1, 0], [width-1, height-1], [0, height-1]], dtype="float32")
            M = cv2.getPerspectiveTransform(rect, dst)
            return cv2.warpPerspective(img, M, (width, height))
    return img  # fallback: return full frame

# ---- preprocess for OCR ----
def preprocess(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    return cv2.adaptiveThreshold(gray, 255,
                                 cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                 cv2.THRESH_BINARY, 31, 10)

# ---- main loop ----
cap = cv2.VideoCapture(0)
print("Press 'c' to capture card text, 'q' to quit")

while True:
    ret, frame = cap.read()
    if not ret: break
    cv2.imshow("Card Scanner", frame)
    k = cv2.waitKey(1) & 0xFF

    if k == ord('c'):
        card = detect_card(frame)  # crop
        proc = preprocess(card)    # clean
        config = "--oem 3 --psm 6 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        text = pytesseract.image_to_string(proc, config=config)
        print("[INFO] OCR:", text.strip())
        append_to_sheet(text.strip())

    elif k == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
